
float mult(float a, float b){
    return a*b+5;
}