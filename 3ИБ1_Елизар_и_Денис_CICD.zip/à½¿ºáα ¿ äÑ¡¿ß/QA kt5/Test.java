import org.example.Main;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.ArgumentsProvider;
import org.junit.jupiter.params.provider.ArgumentsSource;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;


class Test {

    public static String toUp(String a){
        return a.toUpperCase();
    }
    @ParameterizedTest
    @ArgumentsSource(GetArguments.class)
    void test(String start, String result) {
        Assertions.assertEquals(toUp(start), result);
    }


    static class GetArguments implements ArgumentsProvider {
        @Override
        public Stream<? extends Arguments> provideArguments(ExtensionContext context) throws SQLException {
            List<Arguments> result = new ArrayList<>();
            Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/qwer", "postgres", "mydata");

            Statement db = connection.createStatement();
            ResultSet rs = db.executeQuery("SELECT * FROM test");
            while (rs.next()){
                result.add(Arguments.of(rs.getString("start"), rs.getString("result")));
            }
            return result.stream();
        }
    }


}
